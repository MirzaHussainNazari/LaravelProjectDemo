<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
        <li data-target="#myCarousel" data-slide-to="4"></li>
        <li data-target="#myCarousel" data-slide-to="5"></li>
    </ol>

    <div class="carousel-inner">
        <div class="item active">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_a.jpg')); ?>" width="100%" alt="h1"></a>
        </div>

        <div class="item">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_b.jpg')); ?>" width="100%" alt="h2"></a>
        </div>

        <div class="item">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_c.jpg')); ?>" width="100%" alt="h3"></a>
        </div>

        <div class="item">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_d.jpg')); ?>" width="100%" alt="h4"></a>
        </div>
        <div class="item">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_e.jpg')); ?>" width="100%" alt="h5"></a>
        </div>
        <div class="item">
            <a href="#"><img src="<?php echo e(asset('img/slider/Home_f.jpg')); ?>"  width="100%" alt="h6"></a>
        </div>
    </div>
</div>



<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/_includes/slider.blade.php ENDPATH**/ ?>