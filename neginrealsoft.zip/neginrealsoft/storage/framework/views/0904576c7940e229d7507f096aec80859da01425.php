<!doctype html>
<html lang="en">
<head>
    <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Negin Realsoft | Software</title>
</head>
<body id="software">
    <?php echo $__env->make('_includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <img src="<?php echo e(asset('img/software_d/web-app.jpg')); ?>" alt="Cover" style="width: 100%;"  class="img img-responsive center-block">
    <br>
    <div class="container">
        <br>
        <div>
            <h3 class="text-justify" style="margin-left: 1%;">MIS</h3>
            <p style="font-size: 18px;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">
                As of today's and tommorrow's workload and complexity of management and maintainability
                of information, data collection and analysis is becoming a sensitive part of every system
                and business, Negin Realsoft can provide you functional and comprehensive Management Information
                Systems according to your business and management approach for a systematic and modern
                distribution and management of your organization's workflow.
            </p>
             <img src="<?php echo e(asset('img/software_d/MIS1.png')); ?>" alt="MIS" style="height: 80%; " class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-right">
        </div>
    </div>
    <div class="container">
        <br>
        <div>
            <img src="<?php echo e(asset('img/software_d/mobile-app2.png')); ?>" alt="MOBILE" style="height: 80%; margin-top: 7%;" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-left">
            <h3 class="text-justify" style="margin-left: 50.50%;"> Mobile</h3>
            <p style="font-size: 18px; margin-left: 16%;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">
                Negin Realsoft has a strong and innovative approach in mobile application development
                because of its wide range of distribution and usage worldwide inorder to provide
                satisfying applications and masterpieces that can help our clients with ease in
                their business. We offer mobile applications for Android and IOS paltforms using
                the latest technologies for fast and reliable implementation and development of
                your app. If you are having issues or difficulties for implementing your mobile
                app, our experts are here to help and build the application you expect to implement.
            </p>
        </div>
    </div>
    <div class="container">
        <br>
        <div>
            <h3 class="text-justify" style="margin-left: 1%;"> Desktop</h3>
            <p style="font-size: 18px;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">
                Negin Realsoft develops applications that best complies with its clients' needs
                and business inorder to help them challenge competitors in the professional
                field of career for better advancement and popularity. We build desktop
                applications that are the most secure, stable and maintainabe that target
                your aim in the firs place. Our applications are developed with high quality
                software and tools using the best programming laguages that best covers and
                suits your needs.
            </p>
            <img src="<?php echo e(asset('img/software_d/desktopapplication.png')); ?>" alt="Desktop" style="height: 80%; margin-left: 16.50%;" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-left">
        </div>
    </div>
    <?php echo $__env->make('_includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/software.blade.php ENDPATH**/ ?>