<?php $__env->startSection('meta'); ?>
    <title>صفحه اصلی فوتسال</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center mb-3">
    <button type="button" class="btn btn-outline-success">
        <i class="fa fa-plus ml-1"></i> مورد جدید
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fotsal\resources\views/welcome.blade.php ENDPATH**/ ?>