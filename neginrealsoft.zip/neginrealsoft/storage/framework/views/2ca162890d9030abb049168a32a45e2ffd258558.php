<h3 class="col-xs-12 text-center">Our Services</h3>
<br>
<div class="container">
    <h4 class="col-lg-4"><li class="fa fa-cogs"></li> MIS Development</h4>
    <h4 class="col-lg-4"><li class="fa fa-code"></li> Web App Development</h4>
    <h4 class="col-lg-4"><li class="fa fa-mobile"></li> Mobile App Development</h4>
    <h4 class="col-lg-4"><li class="fa fa-desktop"></li> Desktop App Development</h4>
    <h4 class="col-lg-4"><li class="fa fa-database"></li> Website Designing</h4>
    <h4 class="col-lg-4"><li class="fa fa-globe"></li> Host & Domain Registration</h4>
    <h4 class="col-lg-4"><li class="fa fa-user-secret"></li> Secure Hosting</h4>
    <h4 class="col-lg-4"><li class="fa fa-search"></li> Search Engine Optimization</h4>
    <h4 class="col-lg-4"><li class="fa fa-life-ring"></li>24/7 Support</h4>
</div><?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/_includes/services_list.blade.php ENDPATH**/ ?>