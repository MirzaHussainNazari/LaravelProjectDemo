


    <title>صفحه اصلی نگین ریل سافت</title>



<div class="text-center mb-3">
    <button type="button" class="btn btn-outline-success">
        <i class="fa fa-plus ml-1"></i> مورد جدید
    </button>
</div>

<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/welcome.blade.php ENDPATH**/ ?>