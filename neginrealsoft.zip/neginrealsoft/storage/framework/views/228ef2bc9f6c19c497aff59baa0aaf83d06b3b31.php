<footer class="nav panel-footer" style="background: #5e5e5e; color: white; margin-top: 5vh">
    <div class="container"><?php  echo "Copyright &copy" . date("Y") . " Negin Realsoft."; ?></div>
</footer>
<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/_includes/footer.blade.php ENDPATH**/ ?>