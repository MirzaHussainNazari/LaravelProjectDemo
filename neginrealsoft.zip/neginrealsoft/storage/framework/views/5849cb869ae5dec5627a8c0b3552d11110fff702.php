<!doctype html>
<html lang="en">
<head>
    <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Negin Realsoft | Jobs</title>
</head>
<body id="jobs">
    <?php echo $__env->make('_includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container contact-body">
        <div class="panel panel-info">
            <div class="panel-body">
                <div class="col-xs-10 col-xs-offset-1">
                    <h1><li class="fa fa-tasks fa-x10"></li> Jobs </h1>
                </div>
            </div>
        </div>
    </div>
    <footer class="nav navbar-fixed-bottom panel-footer" style="background: #5e5e5e; color: white; margin-top: 5vh">
        <div class="container"><?php  echo "Copyright &copy" . date("Y") . " Negin Realsoft."; ?></div>
    </footer>
</body>
</html>
<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/jobs.blade.php ENDPATH**/ ?>