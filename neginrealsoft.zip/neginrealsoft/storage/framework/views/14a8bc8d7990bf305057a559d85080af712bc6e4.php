<!doctype html>
<html lang="en">
<head>
    <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Negin Realsoft | About</title>
</head>
<body id="about">
    <?php echo $__env->make('_includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <img src="img/about_img/Cover_FF.png" alt="Cover" class="img img-responsive">
    <br>
    <div class="container">
        <div class="panel panel-info">
            <div class="panel-body">
                <div class="col-xs-10 col-xs-offset-1">
                    <h1><li class="fa fa-info fa-x10"></li> About Us</h1>
                </div>
            </div>
        </div>
        <br>
        <div>
            <p style="font-size: 18px;" class="col-lg-8 col-md-8 col-sm-12 col-xs-12 pull-left text-justify">

                Negin Realsoft is an innovative and professional information technology company established
                in December 2017 in Kabul, Afghanstan. Negin Realsoft aims to build its clients' a dream come
                true vision and to provide the high quality and services and products to its clients
                whom include the private and public sectors, Government, individuals and organizations.
                Here at Negin Realsoft, we develop any software that is considered to be a clients' solution in the business.
                No matter, how complex and tricky the implementation of a solution is, we are committed to what we do,
                and what we do is to provide a solution that meets the clients' requirements and today's global business style.
                At Negin Realsoft, we utilize the best technologies together with the best team, who are professionals,
                committed and experts in their field of profession to provide our clients the best services and applications.
            </p>
            <img src="img/about_img/about-us.png" alt="About Us" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-right">
        </div>
    </div>
    <?php echo $__env->make('_includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/about.blade.php ENDPATH**/ ?>