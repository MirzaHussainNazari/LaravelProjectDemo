<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        #map {
            height: 400px;
            width: 100%;
        }
    </style>

    <title>Negin Realsoft | Contact</title>
</head>

<body id="contact">
    <?php echo $__env->make('_includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container contact-body">
        <div class="panel panel-info">
            <div class="panel-body">
                <div class="col-xs-10 col-xs-offset-1">
                    <h1><li class="fa fa-phone fa-x10"></li> Contact Us</h1>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 font-18">
            <p><li class="fa fa-map-pin"></li> Specify Soon...</p>
            <p><li class="fa fa-phone"></li> +93-790-121-735</p>
            <p><li class="fa fa-envelope"></li> mirzanazari77@gmail.com </p>
            <p>
                <li class="fa fa-linkedin"></li>
                <li class="fa fa-facebook"></li>
                <li class="fa fa-twitter"></li>
            </p>
        </div>
        <div class="col-lg-8">
            <form style="margin-left: 20%; margin-top: 3%;" action="<?php $_SERVER['PHP_SELF'] ?>" method="post" class="form-horizontal">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" class="form-control" name="name" placeholder=" Name" required>
                </div>
                <br claa="w-100">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                    <input type="email" class="form-control" name="email" placeholder=" Email" required>
                </div>
                <br claa="w-100">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-comment"></i></span>
                    <input type="text" class="form-control" name="subject" placeholder=" Subject" required>
                </div>
                <br claa="w-100">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-comment"></i></span>
                    <input type="text" class="form-control" name="message" placeholder=" Message" required>
                </div>
                <br>
                <div class="input-group col-lg-10">
                    <input type="submit" name="submit" class="btn btn-primary fa-align-center" style="margin-left: 4%;">
                </div>
                <br claa="w-100">
                <div class="col-lg-9 pull-right">
                    <?php
                        if(isset($_SESSION['email_delivery'])){
                            echo "<div class='panel panel-success'>";
                            echo $_SESSION['email_delivery'];
                            echo "</div>";
                        }
                    ?>
                </div>
            </form>
        </div>

        <div class="col-xs-12" style="padding: 0;">
            <iframe id="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d862.2227918349453!2d69.08564663712755!3d34.50203299875713!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDMwJzA3LjMiTiA2OcKwMDUnMTAuMyJF!5e1!3m2!1sen!2s!4v1516985168110" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>

    </div>
    <?php echo $__env->make('_includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/contact.blade.php ENDPATH**/ ?>