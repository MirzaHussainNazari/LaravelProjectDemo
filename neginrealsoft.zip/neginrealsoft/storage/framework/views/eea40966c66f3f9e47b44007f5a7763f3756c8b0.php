<!--suppress ALL -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css.map')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fa-brands.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fa-brands.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fa-regular.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fa-solid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fa-solid.min.css')); ?>">

<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>


<?php /**PATH C:\wamp64\www\neginrealsoft\resources\views/_includes/head.blade.php ENDPATH**/ ?>