<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('index', function() {
    return view('index');
});

Route::get('software', function () {
    return view('software');
});

Route::get('about', function () {
    return view('about');
});

Route::get('contact', function () {
    return view('contact');
});

Route::get('jobs', function () {
    return view('jobs');
});

Route::get('web_solution', function () {
    return view('web_solution');
});

Route::get('ict', function () {
    return view('ict');
});

Route::get('maintenance', function () {
    return view('maintenance');
});
