<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | Maintenance</title>
</head>
<body id="maintenance">
    @include('_includes.navbar')

    <img src="{{asset('img/maintenance/Maintenance.jpg')}}" alt="Cover" style="width: 100%; height: 4%;"  class="img img-responsive center-block">
    <br>
    <div class="container">
    <br>
        <div>
            <h3 class="text-justify" style="margin-left: 1%;">Maintenance Services</h3>
                <p style="font-size: 18px;" class="col-lg-5 col-md-5 col-sm-9 col-xs-9 pull-left text-justify">
                    we offer unique maintenance services for out customers to keep their business
                    straight. our maintenance provide our customers the best services to keep your
                    application up and running under any circumestances.
                </p>
            <img src="{{asset('img/maintenance/maintenance_cost.png')}}" alt="MIS" style="margin-right: 2%; margin-top: -6%;" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-right">
        </div>
    </div>
    @include('_includes.footer')
</body>
</html>
