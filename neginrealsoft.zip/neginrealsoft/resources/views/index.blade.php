
<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | Home</title>
</head>
<body id="home">
    @include('_includes.navbar')
    @include('_includes.slider')
    @include('_includes.service_box')
    @include('_includes.services_list')
    @include('_includes.footer')
</body>
</html>
