<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | Web Solutions</title>
</head>
<body id="web_solution">
    @include('_includes.navbar')
    <img src="{{asset('img/web_solution/WebDesign.png')}}" alt="Cover" style="width: 100%;"  class="img img-responsive center-block">
    <br>
    <div class="container">
        <br>
        <div>
            <h3 class="text-justify" style="margin-left: 1%;"> Web Application</h3>
            <p style="font-size: 18px;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">
                At Negin Realsoft, we develop interactive and outstandig web applications using our
                creativity and intelligence not only to please you, but also to help your
                business grow and gain fame in your business over competitors.
                Wether your business requires a static website or a dynamic website,
                we assure your web application is developed with the best and cutting
                edge tools and frameworks for high performance, stability, security,
                maintainability and availability.
            </p>
            <img src="{{asset('img/web_solution/web-applications.png')}}" alt="WEB" style="height: 80%; margin-top: -2%;" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-right">
        </div>
    </div>
<div class="container">
    <br>
    <div>
        <img src="{{asset('img/web_solution/web-hosting-company.jpg')}}" alt="WEB" style="height: 80%; " class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-left">
        <h3 class="text-justify" style="margin-left: 50.50%;" id="w_d"> Hosting</h3>
        <p style="font-size: 18px; margin-left: 16%;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">
            We offer our customers the most secure and highly available hosting from the world's
            best host providers to ensure the availability of the website at the rate of 99.999 %
            of the time. we provide a hosting platform for almost any application and content
            with the highest uptime to make sure your website is reahable at any time.
        </p>
    </div>
</div>
<div class="container">
    <br>
    <div>
        <h3 class="text-justify" style="margin-left: 1%;">Domain</h3>
        <p style="font-size: 18px;" class="col-lg-5 col-md-5 col-sm-9 col-xs-9 pull-left text-justify">
            We help you find and register the domain of your choice within the shortest way
            and lowest price. to check out your domain name's price and availability,
            send us an email at info@btbeaver.com.
        </p>
        <img src="{{asset('img/web_solution/domain-and-hosting.jpg')}}" alt="W_He" style="height: 80%; " class="img img-responsive col-lg-5 col-md-5 hidden-sm hidden-xs pull-right">
    </div>
</div>
@include('_includes.footer')
</body>
</html>
