<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | ICT</title>
</head>
<body id="ict">
    @include('_includes.navbar')
    <img src="{{asset('img/ict_img/netDesign.png')}}" alt="Cover" style="width: 100%;"  class="img img-responsive center-block">
    <br>
    <div class="container">
        <br>
        <div>
            <h3 class="text-justify" style="margin-left: 1%;"> Network Design & Implementation</h3>
            <p style="font-size: 18px;" class="col-lg-6 col-md-6 col-sm-10 col-xs-10 pull-left text-justify">

                Keeping your business running smoothly requires building and maintaining a robust,
                highly available network. Systems Engineering offers proven network design and
                implementation services that drive results for your business.

                Modern communications networks can be highly complex and demanding which can distract
                you from focusing as much energy as possible on your core revenue generating functions.
                By conducting a comprehensive audit of all your sites, business units, systems and
                applications we can design your network from the bottom up, ensuring it can meet the
                demands of the platforms, applications and volumes of data that you use, as well as
                making sure that your networks are able to deal with growth.

                The team can design any aspect of a modern communications network, including disaster
                recovery systems from our data centre which ensure total resilience.
            </p>
            <img src="{{asset('img/ict_img/network1.png')}}" alt="Desktop" style="height: 80%; margin-left: 16.50%;" class="img img-responsive col-lg-4 col-md-4 hidden-sm hidden-xs pull-left">
        </div>
    </div>
    @include('_includes.footer')
</body>
