<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | Services</title>
</head>
<body id="services">
    @include('_includes.navbar')
    @include('_includes.footer')
</body>
</html>
