<br>
<div class="container">
    <div class="panel panel-info">
        <div class="panel-body">
            <div class="col-lg-3 col-md-3 col-sm-6 text-center">
            <a href="{{url('software')}}">
                    <li class="fa fa-code fa-10x"></li>
                    <br>
                    <h4>Software Development</h4>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 text-center">
            <a href="{{url('web_solution')}}">
                    <li class="fa fa-globe fa-10x"></li>
                    <br>
                    <h4>Web Solutions</h4>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 text-center">
                <a href="{{url('ict')}}">
                    <li class="fa fa-handshake fa-10x"></li>
                    <br>
                    <h4>ICT Consulting</h4>
                </a>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 text-center">
                <a href="{{url('maintenance')}}">
                    <li class="fa fa-cogs fa-10x"></li>
                    <br>
                    <h4>Maintenance Services</h4>
                </a>
            </div>
        </div>
    </div>
</div>
