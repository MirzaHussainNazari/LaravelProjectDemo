<nav class="navbar navbar-default navbar-fixed-top trans" style="margin-bottom: 5px;">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{url('index')}}"><span class="fa fa-code color-blue"> Negin Realsoft</span></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav pull-right">
                <li><a href="{{url('index')}}"><span class="fa fa-home color-blue"> Home</span></a></li>
                <li class="dropdown">
                <a href="{{url('index')}}" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="fa fa-cogs color-blue"> Services </span>
                        <span class="fa fa-caret-down color-blue"></span>
                    </a>
                    <ul class="dropdown-menu">
                    <li><a href="{{url('software')}}"><span class="fa fa-code color-blue"> Software Development</span></a></li>
                        <li><a href="{{url('ict')}}"><span class="fa fa-handshake color-blue"> ICT Consulting</span></a></li>
                        <li><a href="{{url('web_solution')}}"><span class="fa fa-globe color-blue"> Web Solutions</span></a> </li>
                        <li><a href="{{url('maintenance')}}"><span class="fa fa-cogs color-blue"> Maintenance</span></a> </li>
                    </ul>
                </li>
                <li><a href="{{url('about')}}"><span class="fa fa-info color-blue"> About</span></a></li>
                <li><a href="{{url('contact')}}"><span class="fa fa-phone color-blue"> Contact</span></a></li>
                <li><a href="{{url('jobs')}}"><span class="fa fa-tasks color-blue"> Jobs </span></a></li>
            </ul>
        </div>
    </div>
</nav>
