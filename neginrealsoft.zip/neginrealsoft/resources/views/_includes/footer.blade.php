<footer class="nav panel-footer" style="background: #5e5e5e; color: white; margin-top: 5vh">
    <div class="container"><?php  echo "Copyright &copy" . date("Y") . " Negin Realsoft."; ?></div>
</footer>
