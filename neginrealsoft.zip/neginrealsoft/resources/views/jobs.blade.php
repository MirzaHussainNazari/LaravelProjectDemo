<!doctype html>
<html lang="en">
<head>
    @include('_includes.head')
    <title>Negin Realsoft | Jobs</title>
</head>
<body id="jobs">
    @include('_includes.navbar')
    <div class="container contact-body">
        <div class="panel panel-info">
            <div class="panel-body">
                <div class="col-xs-10 col-xs-offset-1">
                    <h1><li class="fa fa-tasks fa-x10"></li> Jobs </h1>
                </div>
            </div>
        </div>
    </div>
    <footer class="nav navbar-fixed-bottom panel-footer" style="background: #5e5e5e; color: white; margin-top: 5vh">
        <div class="container"><?php  echo "Copyright &copy" . date("Y") . " Negin Realsoft."; ?></div>
    </footer>
</body>
</html>
