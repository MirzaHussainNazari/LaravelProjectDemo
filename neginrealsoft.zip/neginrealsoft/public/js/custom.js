$(function () {
    //highlight current nav
    $("#home a:contains('Home')").parent().addClass('active');
    $("#services a:contains('Services')").parent().addClass('active');
    $("#software a:contains('Services')").parent().addClass('active');
    $("#ict a:contains('Services')").parent().addClass('active');
    $("#about a:contains('About')").parent().addClass('active');
    $("#contact a:contains('Contact')").parent().addClass('active');
    $("#jobs a:contains('Jobs')").parent().addClass('active');

    //make menus drop automatically
    $('ul.nav li.dropdown').hover(function () {
        $('.dropdown-menu', this).fadeIn();
    }, function () {
        $('.dropdown-menu', this).fadeOut('fast');
    });//hover
})